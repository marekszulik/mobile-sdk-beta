# Tremor - adapter changelog

####2.1.0

- Added support for Tremor 3.9
- Dropped support for iOS 5

####2.0.0

- Added support for Tremor 3.8
- Added interstitial mediation adapter
- Added rewarded video mediation adapter