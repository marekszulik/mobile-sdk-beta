# Facebook - adapter changelog

####2.0.1

- Added support for Facebook SDK 3.23 
- Added support for Facebook SDK 3.20
- Supports only iOS 7 or higher

####2.0.0

- Added interstitial mediation adapter