# MediaBrix - adapter changelog


####2.0.0

- Added support for MediaBrix 1.6.1
- Added rewarded video mediation adapter