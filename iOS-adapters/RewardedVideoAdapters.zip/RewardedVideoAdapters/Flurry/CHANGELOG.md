# Flurry for Advertisers - adapter changelog

####2.5.0

- Added support for Flurry 6.2.0

####2.4.1

- Improved pre-caching logic for the rewarded video mediation adapter
- Fixed a bug which could cause unexpected behaviour in case of a rendering error or a click action error from Flurry

####2.4.0

- Added pre-caching to the rewarded video mediation adapter

####2.3.0

- Added support for Flurry 6.0.0


####2.2.1

 - Fixed a bug which causes rare crashes when nil was provided as an error object.


####2.2.0 

- Added support for Flurry 5.4.0
- Added interstitial mediation adapter

####2.1.0 

- Added support for Flurry 5.3.0
- Added an option which allows to change Flurry log level in the `.plist` file.
 
####2.0.0

- Added rewarded video mediation adapter