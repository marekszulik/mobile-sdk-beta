//
//  SPMediabrixNetwork.m
//
//  Created on 12/15/14.
//  Copyright (c) 2014 Fyber. All rights reserved.
//

#import "SPBaseNetwork.h"

@interface SPMediabrixNetwork : SPBaseNetwork

@property (nonatomic, readonly) NSString *appId;
@property (nonatomic, readonly) NSString *rescueZone;

@end
