//
//  SPFacebookNetwork.m
//  SponsorPayTestApp
//
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import "SPBaseNetwork.h"

@interface SPFacebookAudienceNetworkNetwork : SPBaseNetwork

@property (nonatomic, copy, readonly) NSString *placementId;

@end
