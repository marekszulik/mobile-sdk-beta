//
//  SPAppleIAdNetwork.m
//  SponsorPay iOS SDK - InMobi Adapter v.2.0.0
//
//  Created by Paweł Kowalczyk on 03.06.2014.
//  Copyright (c) 2014 SponsorPay. All rights reserved.
//

#import "SPBaseNetwork.h"
#import <iAd/iAd.h>

@interface SPAppleIAdNetwork : SPBaseNetwork

@end
